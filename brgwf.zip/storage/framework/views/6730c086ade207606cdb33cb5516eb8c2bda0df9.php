<?php $__env->startSection('title', 'BRGWF Non Member List'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">

            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Non Member Lists</h3>
                    <form action="<?php echo e(route('non-member.filter')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row" style="display: flex; justify-content: center;">

                            <label for="factory">Organization</label>
                            <select class="mx-2" name="factory" id="factory">
                                <option value="">Select One</option>
                                <?php $__currentLoopData = $factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($factory->id); ?>"><?php echo e($factory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <label for="category">Category</label>
                            <select class="mx-2" name="category" id="category">
                                <option>Select One </option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input class="minimal" type="checkbox" name="is_active" id="is_active" value="1" checked style="margin-top: 7px; margin-right: 5px; margin-left: 20px;">
                            <label for="is_active">Is Active</label>
                            <button type="submit" class="ml-4 btn btn-primary">Filter</button>
                        </div>
                    </form>
                    <div class="d-flex" style="justify-content: flex-end;">
                        <?php echo e($members->links()); ?>

                    </div>
                    <hr>
                    <span class="float-right"><a class="btn btn-info" href="<?php echo e(route('non-member.create')); ?>">Add
                            New</a></span>
                </div>

                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>
                                    ID (Membership No) <br>
                                    Card No / NID <br>
                                    Factory ID
                                </th>
                                <th>
                                    Name <br>
                                    Father Name <br>
                                    Mother Name
                                </th>
                                <th>
                                    DOB <br>
                                    Religion <br>
                                    Gender
                                </th>
                                <th>
                                    Union
                                </th>
                                <th>
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <img src="<?php echo e(asset('member_image/'.$member->photo)); ?>" style="width:90px" onerror="this.onerror=null;this.src='<?php echo e(asset('member_image/no_photo.png')); ?>';">
                                </td>
                                <td>
                                    <?php echo e($member->membership_no); ?> <br>
                                    <?php echo e($member->nid); ?> <br>
                                    <?php echo e($member->factory_id_no); ?>

                                </td>
                                <td>
                                    <?php echo e($member->full_name); ?> <br>
                                    <?php echo e($member->father_name); ?> <br>
                                    <?php echo e($member->mother_name); ?>

                                </td>
                                <td>
                                    <?php echo e(date('d-M-y',strtotime($member->dob))); ?> <br>
                                    <?php echo e($member->religion->name ?? 'N/A'); ?> <br>
                                    <?php echo e($member->gender); ?>

                                </td>
                                <td>
                                    <?php echo e($member->factory->name ?? 'N/A'); ?>

                                </td>
                                <td class="d-flex justify-content-between">
                                    <a href="<?php echo e(route('non-member.edit', $member->id)); ?>" class="btn btn-outline-info">&#9998; Edit</a>
                                    <a href="<?php echo e(route('training-assign.create')); ?>">Training</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#example1').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': true
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/member/view-non-member.blade.php ENDPATH**/ ?>