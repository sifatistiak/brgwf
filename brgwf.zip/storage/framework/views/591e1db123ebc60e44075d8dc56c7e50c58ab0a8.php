<?php $__env->startSection('title', 'BRGWF Factory Edit'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Edit Factory</h3>
                    <hr>

                </div>
                <div class="clearfix"></div>
                <!-- /.box-header -->
                <!-- form start -->
                <form role="form" action="<?php echo e(route('factory.update',$factory->id)); ?>" method="post">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="name">Union</label>
                                <select class="form-control input-group col-md-9" id="union_id" name="union_id">
                                    <option value="">Select One</option>
                                    <?php $__currentLoopData = $unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($union->id); ?>"
                                        <?php echo e(($factory->union_id == $union->id)?'selected':''); ?>><?php echo e($union->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="name">Name</label>
                                <input type="text" class="form-control input-group col-md-9" id="name" name="name"
                                    value="<?php echo e($factory->name); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="phone">Phone</label>
                                <input type="text" class="form-control input-group col-md-3" id="phone" name="phone"
                                    value="<?php echo e($factory->phone); ?>">
                                <span class="input-group-addon col-md-1"></span>
                                <label class="col-md-2" for="contact_person">Category</label>
                                <select class="form-control input-group col-md-3" id="factory_category_id"
                                    name="factory_category_id">
                                    <option value="">Select One</option>
                                    <?php $__currentLoopData = $factory_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>"
                                        <?php echo e(($factory->factory_category_id == $cat->id)?'selected':''); ?>><?php echo e($cat->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="email">Email</label>
                                <input type="email" class="form-control input-group col-md-3" id="email" name="email"
                                    value="<?php echo e($factory->email); ?>">
                                <span class="input-group-addon col-md-1"></span>
                                <label class="col-md-2" for="reg_no">Registration No</label>
                                <input type="text" class="form-control input-group col-md-3" id="reg_no" name="reg_no"
                                    value="<?php echo e($factory->reg_no); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="contact_person">Contact Person</label>
                                <input type="text" class="form-control input-group col-md-3" id="contact_person"
                                    value="<?php echo e($factory->contact_person); ?>" name="contact_person">
                                <span class="input-group-addon col-md-1"></span>
                                <label class="col-md-2" for="no_of_workers">No of Workers</label>
                                <input type="text" class="form-control input-group col-md-3" id="no_of_workers"
                                    value="<?php echo e($factory->no_of_workers); ?>" name="no_of_workers">
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="present_address">Present Address</label>
                                <textarea class="form-control input-group col-md-9" id="present_address"
                                    name="present_address"><?php echo e($factory->present_address); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="permanent_address">Permanent Address</label>
                                <textarea class="form-control input-group col-md-9" id="permanent_address"
                                    name="permanent_address"><?php echo e($factory->permanent_address); ?></textarea>
                            </div>
                        </div>

                        <div class="ml-5 pl-5 checkbox col-md-8 d-flex justify-content-between">
                            <label>
                                Is Accord
                                <input type="checkbox" name="is_accord" value="1"
                                    <?php echo e(($factory->is_accord)?'checked':''); ?>>
                            </label>
                            <span class="input-group-addon col-1"></span>
                            <label>
                                Is Alliance
                                <input type="checkbox" name="is_alliance" value="1"
                                    <?php echo e(($factory->is_alliance)?'checked':''); ?>>
                            </label>
                            <span class="input-group-addon col-1"></span>
                            <label>
                                Is Non Compliance
                                <input type="checkbox" name="is_non_compliance" value="1"
                                    <?php echo e(($factory->is_non_compliance)?'checked':''); ?>>
                            </label>
                            <span class="input-group-addon col-1"></span>
                            <label>
                                NAP
                                <input type="checkbox" name="is_nap" value="1" <?php echo e(($factory->is_nap)?'checked':''); ?>>
                            </label>
                            <span class="input-group-addon col-1"></span>
                            <label>
                                Is Active
                                <input type="checkbox" name="is_active" value="1"
                                    <?php echo e(($factory->is_active)?'checked':''); ?>>
                            </label>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer mt-5 col-md-11">
                        <a href="<?php echo e(route('factory.index')); ?>" class="btn btn-info">Back to List</a>
                        <button type="submit" class="btn btn-success float-right">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/factory/edit.blade.php ENDPATH**/ ?>