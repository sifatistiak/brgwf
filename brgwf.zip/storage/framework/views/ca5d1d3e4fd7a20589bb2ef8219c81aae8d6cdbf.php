<?php $__env->startSection('title', 'BRGWF'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="m-0 text-dark">Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-blue"><i class="fas fa-user"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Members</span>
                <span class="info-box-number"><?php echo e(App\Models\Models\Member::count()); ?></span>
            </div><!-- /.info-box-content -->
        </div><!-- /.info-box -->
    </div><!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fas fa-users-cog"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Unions</span>
                <span class="info-box-number"><?php echo e(App\Models\Models\Union::count()); ?></span>
            </div><!-- /.info-box-content -->
        </div><!-- /.info-box -->
    </div><!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fas fa-industry"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Factories</span>
                <span class="info-box-number"><?php echo e(App\Models\Models\Factory::count()); ?></span>
            </div><!-- /.info-box-content -->
        </div><!-- /.info-box -->
    </div><!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fas fa-star"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">Training</span>
                <span class="info-box-number"><?php echo e(App\Models\Models\Training::count()); ?></span>
            </div><!-- /.info-box-content -->
        </div><!-- /.info-box -->
    </div><!-- /.col -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/home.blade.php ENDPATH**/ ?>