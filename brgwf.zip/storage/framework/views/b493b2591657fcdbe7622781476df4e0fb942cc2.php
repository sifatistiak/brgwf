<?php $__env->startSection('title', 'BRGWF Training Add'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-10">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Assign Training</h3>
                    <hr>
                </div>
                <div class="clearfix"></div>
                <!-- /.box-header -->
                <!-- form start -->
                <form action="<?php echo e(route('training-assign.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="training_id">Training Name</label>

                                <select name="training_id" id="training_id" class="form-control input-group col-md-10">
                                    <option></option>
                                    <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($training->id); ?>"><?php echo e($training->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="ml-5 checkbox col-md-8 d-flex justify-content-between">
                            <label>
                                Is For Non Member ?
                                <input type="checkbox" name="is_for_non_member" value="1" onchange="ShowHideDiv(this)">
                            </label>
                        </div>
                        <br>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="union">Unions</label>

                                <select name="union" id="union" class="form-control input-group col-md-4">
                                    <option></option>
                                    <?php $__currentLoopData = $unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($union->id); ?>"><?php echo e($union->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="input-group-addon col-md-1"></span>

                                <label class="col-md-2" for="factory">Factory</label>
                                <select name="factory" id="factory" class="form-control input-group col-md-4">
                                    <option></option>
                                    <?php $__currentLoopData = $factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($factory->id); ?>"><?php echo e($factory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="member_name">Member Name</label>
                                <div id="for_member">
                                    <select name="member_name[]" id="member_name" multiple="multiple" class="input-group col-md-12 js-example-basic-multiple">
                                        <option></option>
                                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member_name->full_name); ?>"><?php echo e($member_name->full_name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <span class="input-group-addon col-md-1"></span>

                                <label class="col-md-2" for="training_date">Training Date</label>
                                <input type="date" class="form-control input-group col-md-4" id="training_date" name="training_date">

                            </div>
                        </div>


                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="trainer_id">Trainer Name</label>
                                <select name="trainer_id" id="trainer_id" class="form-control input-group col-md-4">
                                    <option></option>
                                    <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trainer->id); ?>"><?php echo e($trainer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="input-group-addon col-md-1"></span>

                                <label class="col-md-2" for="organized_by">Organized By</label>
                                <input type="text" class="form-control input-group col-md-4" id="organized_by" name="organized_by">

                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="center_name">Center Name</label>
                                <input type="text" class="form-control input-group col-md-10" id="center_name" name="center_name">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <label class="col-md-2" for="remarks">Remarks</label>
                                <input type="text" class="form-control input-group col-md-10" id="remarks" name="remarks">
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->


                    <div class="box-footer mt-5">
                        <button type="submit" class="btn btn-success float-right">Submit Create</button>
                    </div>
                </form>
            </div>
            <!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#member_name').select2();
    $('#non_member_name').select2();
    $('#for_non_member').hide();

    function ShowHideDiv(chk) {
        var member_name = document.getElementById("member_name");
        var non_member_name = document.getElementById("non_member_name");
        if ($(chk).is(":checked")) {

            document.getElementById("factory").disabled = true;
            document.getElementById("union").disabled = true;


            var data = `<select name="member_name[]" id="member_name" multiple="multiple" class="js-example-basic-multiple input-group col-md-12">
                <option></option>
                <?php $__currentLoopData = $nonmembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($member_name->full_name); ?>"><?php echo e($member_name->full_name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>`;
            $('#for_member').html(data);
            $('#member_name').select2();

        } else {
            document.getElementById("factory").disabled = false;
            document.getElementById("union").disabled = false;

            var data = `<select name="member_name[]" id="member_name" multiple="multiple" class="js-example-basic-multiple input-group col-md-12">
            <option></option>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($member_name->full_name); ?>"><?php echo e($member_name->full_name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>`;
            $('#for_member').html(data);
            $('#member_name').select2();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/training-assign/add.blade.php ENDPATH**/ ?>