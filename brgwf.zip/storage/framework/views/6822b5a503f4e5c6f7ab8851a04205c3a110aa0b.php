<?php $__env->startSection('title', 'BRGWF Member Edit'); ?>

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.swf">
<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <p class="mb-0">Membership</p>
                </div>
                <div class="card-body">
                    <form class="form-horizontal" action="<?php echo e(route('member.update',$member->id)); ?>"
                        enctype="multipart/form-data" method="post">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label class="control-label col-md-2" for="union_id">Union</label>
                                    <div class="col-md-11">
                                        <select class="form-control col-md-12" id="union_id" name="union_id">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($union->id); ?>"
                                                <?php echo e(($union->id == $member->union_id)?"selected":''); ?>><?php echo e($union->name); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2" for="factory_id">Factory</label>
                                    <div class="col-md-11">
                                        <select class="form-control" id="factory_id" name="factory_id">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $factories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($factory->id); ?>"
                                                <?php echo e(($factory->id == $member->factory_id)?"selected":''); ?>>
                                                <?php echo e($factory->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-4" for="full_name">Name</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="full_name" name="full_name" required="required"
                                            type="text" value="<?php echo e($member->full_name); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-4" for="gender">Gender</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="gender" name="gender">
                                            <option value="Male" <?php echo e(($member->gender == "Male") ? "selected" : ""); ?>>
                                                Male</option>
                                            <option value="Female"
                                                <?php echo e(($member->gender == "Female") ? "selected" : ""); ?>>Female</option>
                                            <option value="Other" <?php echo e(($member->gender == "Other") ? "selected" : ""); ?>>
                                                Other</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="date_of_birth">Date Of Birth</label>
                                    <div class="col-md-9">
                                        <input class="form-control datepicker" id="date_of_birth" name="date_of_birth"
                                            type="date" value="<?php echo e($member->date_of_birth); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="religion_id">Religion</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="religion_id" name="religion_id">
                                            <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($religion->id); ?>"
                                                <?php echo e(($religion->id == $member->religion_id)?"selected":''); ?>>
                                                <?php echo e($religion->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="reg_no">RegNo</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="reg_no" name="reg_no" type="text"
                                            value="<?php echo e($member->reg_no); ?>">

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="father_name">Father Name</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="father_name" name="father_name" type="text"
                                            value="<?php echo e($member->father_name); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="mother_name">Mother Name</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="mother_name" name="mother_name" type="text"
                                            value="<?php echo e($member->mother_name); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="blood_group">Blood Group</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="blood_group" name="blood_group">
                                            <option value="A+" <?php echo e(($member->blood_group == "A+") ? "selected" : ""); ?>>A+
                                            </option>
                                            <option value="A-" <?php echo e(($member->blood_group == "A-") ? "selected" : ""); ?>>A-
                                            </option>
                                            <option value="B+" <?php echo e(($member->blood_group == "B+") ? "selected" : ""); ?>>B+
                                            </option>
                                            <option value="B-" <?php echo e(($member->blood_group == "B-") ? "selected" : ""); ?>>B-
                                            </option>
                                            <option value="AB+" <?php echo e(($member->blood_group == "AB+") ? "selected" : ""); ?>>
                                                AB+</option>
                                            <option value="AB-" <?php echo e(($member->blood_group == "AB-") ? "selected" : ""); ?>>
                                                AB-</option>
                                            <option value="O+" <?php echo e(($member->blood_group == "O+") ? "selected" : ""); ?>>O+
                                            </option>
                                            <option value="O-" <?php echo e(($member->blood_group == "O-") ? "selected" : ""); ?>>O-
                                            </option>
                                        </select>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-4" for="spouse_name">Spouse Name</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="spouse_name" name="spouse_name" type="text"
                                            value="<?php echo e($member->spouse_name); ?>">

                                    </div>
                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="input-group input-group-sm">
                                    <label class="control-label col-md-12" for="photo">Photo</label>
                                    <input accept="image/*" class="form-control col-md-5" id="photo" name="photo"
                                        onchange="readURL(this);" type="file" style="height:auto;">
                                    <span class="input-group-btn">
                                        <a id="webcam" class="form-control btn btn-success" onclick="showCamera();"> <i
                                                class="fa fa-camera"> &nbsp; Use Camera</i> </a>
                                    </span>

                                </div>


                                <img id="blah" class="img-thumbnail" src="<?php echo e(asset('member_image/'.$member->photo)); ?>"
                                    style="float:left; width:250px; height:200px; margin-right:10px; margin-top: 25px;">


                                <div class="row col-md-6">

                                    <div id="my_camera" style="width:250px; height:250px;"></div>

                                </div>
                                <a id="takesnap" class="btn btn-warning" href="javascript:void(take_snapshot())">Take
                                    Snapshot</a>
                                <a id="close" class="btn btn-danger" href="javascript:void(hideCamera())">Close</a>

                                <input id="webimg" type="hidden" name="webimg" value="" />

                                <div class="clearfix"></div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="mobile">Mobile</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="mobile" name="mobile" type="text"
                                            value="<?php echo e($member->mobile); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="education_id">Education</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="education_id" name="education_id">
                                            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($education->id); ?>"
                                                <?php echo e(($education->id == $member->education_id)?"selected":''); ?>>
                                                <?php echo e($education->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-2" for="nid">NID No</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="nid" name="nid" type="text" value="">

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-4" for="designation_id">Designation</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="designation_id" name="designation_id">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($designation->id); ?>"
                                                <?php echo e(($designation->id == $member->designation_id)?"selected":''); ?>>
                                                <?php echo e($designation->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="category_id">Member Categories</label>
                                    <div class="col-md-9">
                                        <select class="form-control" id="category_id" name="category_id">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $member_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php echo e(($category->id == $member->category_id)?"selected":''); ?>>
                                                <?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="joining_date">Joining Date</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="joining_date" name="joining_date" type="date"
                                            value="<?php echo e($member->joining_date); ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-4" for="FactoryJoiningDate">Factory(Join)
                                        Date</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="factory_joining_date"
                                            name="factory_joining_date" type="date"
                                            value="<?php echo e($member->factory_joining_date); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-4" for="factory_id_no">Factory Id</label>
                                    <div class="col-md-9">
                                        <input class="form-control" id="factory_id_no" name="factory_id_no" type="text"
                                            value="<?php echo e($member->factory_id_no); ?>">

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2" for="is_wpc">
                                        <input id="is_wpc" name="is_wpc" type="checkbox" class="minimal" value="1"
                                            <?php echo e(($member->is_wpc == 1) ? 'checked' : ''); ?>>
                                        Is WPC
                                    </label>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-2" for="is_paid">
                                        <input id="is_paid" name="is_paid" type="checkbox" class="minimal" value="1"
                                            <?php echo e(($member->is_paid == 1) ? 'checked' : ''); ?>>
                                        Is Paid
                                    </label>
                                </div>

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="present_address">Present Address</label>
                            <div class="col-md-8">
                                <textarea class="form-control" cols="20" id="present_address" name="present_address"
                                    rows="3"><?php echo e($member->present_address); ?></textarea>

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-2" for="permanent_address">Permanent Address</label>
                            <div class="col-md-8">
                                <textarea class="form-control" cols="20" id="permanent_address" name="permanent_address"
                                    rows="3"><?php echo e($member->permanent_address); ?></textarea>

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-2" for="is_active">
                                <input id="is_active" name="is_active" value="1" type="checkbox" class="minimal"
                                    <?php echo e(($member->is_active == 1) ? 'checked' : ''); ?>>
                                Is Active
                            </label>
                        </div>

                        <a class="btn btn-info" href="<?php echo e(route('member.index')); ?>">Back to List</a>
                        <input type="submit" name="save" value="Update" class="btn btn-primary pull-right">

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.js"
    integrity="sha512-AQMSn1qO6KN85GOfvH6BWJk46LhlvepblftLHzAv1cdIyTWPBKHX+r+NOXVVw6+XQpeW4LJk/GTmoP48FLvblQ=="
    crossorigin="anonymous"></script>
<script>
    $('#takesnap').hide();
    $('#close').hide();

    function readURL(input) {
        if (input.files && input.files[0]) {
            document.getElementById('webimg').value = '';
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }

    $("#imgInp").change(function() {
        readURL(this);
    });

    function showCamera() {
        Webcam.attach('#my_camera');
        Webcam.set({
            width: 250,
            height: 250
        });
        $("#webcam").attr("onclick", "hideCamera()");
        $('#takesnap').show();
        $('#close').show();
    }

    function hideCamera() {
        Webcam.reset('#my_camera');
        $("#webcam").attr("onclick", "showCamera()");
        $('#takesnap').hide();
        $('#close').hide();
    }


    function take_snapshot() {
        Webcam.snap(function(data_uri) {
            document.getElementById('blah').src = data_uri;
            var raw_image_data = data_uri.replace(/^data\:image\/\w+\;base64\,/, '');

            document.getElementById('webimg').value = raw_image_data;
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/member/edit.blade.php ENDPATH**/ ?>