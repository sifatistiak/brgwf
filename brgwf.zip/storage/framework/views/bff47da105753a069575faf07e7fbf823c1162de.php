<?php $__env->startSection('title', 'BRGWF Training List'); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Training List</h3>
                    <hr>
                    <span class="float-right"><a class="btn btn-info" href="<?php echo e(route('training.create')); ?>">Add New</a></span>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Duration</th>
                                <th>Active</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($loop->index+1); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                                <td> <?php echo e($item->code); ?> </td>
                                <td> <?php echo e($item->duration); ?> </td>
                                <td>
                                    <?php if($item->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>

                                <td class="d-flex justify-content-between">
                                    <a href="<?php echo e(route('training.edit', $item->id)); ?>" class="btn btn-outline-info">&#9998; Edit</a>

                                    <?php echo e(Form::open(['route' => ['training.destroy', $item->id], 'method' => 'delete'])); ?>

                                    <button class="btn btn-danger" type="submit">Delete</button>
                                    <?php echo e(Form::close()); ?>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#example1').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': true
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Hasib Vai\Projects\brgwf\resources\views/training/view.blade.php ENDPATH**/ ?>